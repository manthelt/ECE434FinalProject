BeagleBone Black 3D Model
=========================
 
SolidWorks 3D model of the BeagleBone Black

Contains the following:
- SolidWorks, IGES, STEP, STL files
- 3D PDF (open in Adobe Reader)

### To download, click "Download ZIP" to the right   ==>

Made available by Logic Supply based on information from BeagleBoard.org

Visit Logic Supply to buy the BeagleBone Black and accessories at http://www.logicsupply.com/products/bb_bblk_000

Follow us on Google+ for updates and more information: https://plus.google.com/u/0/b/103613886667848850929/

Designed by Rodney Hill and Hans Brakeley for Logic Supply.

Creative Commons Attribution 3.0 Unported License. To view a copy of this license,
visit http://creativecommons.org/licenses/by/3.0/. All text above must be included in any redistribution.
